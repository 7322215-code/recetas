package com.example.recetitas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecetitasApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecetitasApplication.class, args);
	}

}
