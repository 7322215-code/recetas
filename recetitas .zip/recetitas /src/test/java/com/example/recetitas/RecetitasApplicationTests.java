package com.example.recetitas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecetitasApplicationTests {

	@Test
	void contextLoads() {
	}

}
